from threading import Thread
import socket
import json
import pandas as pd
import numpy as np
import math
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import string
import re
def wrap(data):
    return bytes(json.dumps(data).encode('utf-8'))
class LocalServer(object):
    def ccut(self,x):
        for i in range(0,3):
            x[i] = re.sub('[^A-Za-z]+', ' ', x[i]).lower()
            x[i] = x[i].translate(self.remove)
            x[i] = self.lemmatizer.lemmatize(x[i])
            x[i] = word_tokenize(x[i])
        return x
    def getdt(self,x):
        for i in range(0,3):
            for word in x[i]:
                if word in self.dt:
                    self.dt[word] += 1
                else:
                    self.dt[word] = 1
        return x
    def getset(self,x):
        return set(x[1])
    def getTF_IDF(self,x):
        dt = {}
        for word in x[1]:
            if word in dt:
                dt[word] += 1
            else:
                dt[word] = 1
        ls = []
        for word in list(self.dt.keys()):
            if word in dt:
                ls.append(dt[word] / len(x[1]) * self.dt[word])
            else:
                ls.append(0)
        return ls
    
    def __init__(self, host, port):
        print("local server is initing...")
        self.address = (host, port)

        self.data = pd.read_csv('data/all_news.csv')
        self.doc = pd.read_csv('data/all_news.csv')
        self.stop_words = set(stopwords.words('english'))
        #print((self.stop_words))
        self.remove = str.maketrans('','',string.punctuation)
        self.lemmatizer = WordNetLemmatizer()
        self.data = self.data.apply(self.ccut,axis = 1)
        self.dt = {}
        self.data = self.data.apply(self.getdt,axis = 1)
        for x in list(self.dt.keys()):
            if self.dt[x] < 20:
                del self.dt[x]
        #print(len(self.dt))
        self.data['setword'] = self.data.apply(self.getset,axis = 1)
        self.pos = {}
        ls = list(self.dt.keys())
        
        for i in range(len(ls)):
            self.pos[ls[i]] = i
            cnt = 0
            for s in self.data['setword']:
                if x in s:
                    cnt += 1
            self.dt[x] = math.log(len(self.data['setword']) / cnt)
            #print(self.dt[x])
        self.data['TF-IDFvec'] = self.data.apply(self.getTF_IDF,axis = 1)
        self.data.to_csv('cut.csv')
    def find(self,terms):
        ls = []
        pos = [self.pos[w] for w in terms]
        for i in range(len(self.data['TF-IDFvec'])):
            v = self.data['TF-IDFvec'][i]
            c = 0
            for p in pos:
                c += v[p]
            ls.append((i,c))
        ls.sort(key = lambda x : -x[1])
        ret = []
        for x in ls[:10]:
            ret.append((self.doc['title'][x[0]],self.doc['body'][x[0]]))
        return ret
    def serve(self,new_socket,client_info):
        print("client{} has been connected".format(client_info))
        raw_data = new_socket.recv(1024)
        while raw_data:
            data = json.loads(raw_data)
            print('data is {}'.format(data))
            new_socket.send(wrap(self.find(data)))
            raw_data = new_socket.recv(1024)
        new_socket.close()
    def run(self):
        print('local server is running...')
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(self.address)
        server.listen(5)
        new_socket,client_info = server.accept()
        p = Thread(target = self.serve,args = (new_socket,client_info))
        p.start()
        
        
        """
        TODO：请在服务器端实现合理的并发处理方案，使得服务器端能够处理多个客户端发来的请求
        """
    
        """
        TODO: 请补充实现文本检索，以及服务器端与客户端之间的通信
        
        1. 接受客户端传递的数据， 例如检索词
        2. 调用检索函数，根据检索词完成检索
        3. 将检索结果发送给客户端，具体的数据格式可以自己定义
        
        """
#nltk.download('punkt')
server = LocalServer("127.0.0.1", 9001)
server.run()